package virtualtree;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

public class VirtualTree {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Display display = new Display();
		Shell shell = new Shell(display);
		
		final Tree tree = new Tree(shell, SWT.VIRTUAL | SWT.BORDER);
		tree.setItemCount(20);
		tree.addListener(SWT.SetData, new Listener() {
			public void handleEvent(Event event) {
				TreeItem item = (TreeItem)event.item;
				TreeItem parentItem = item.getParentItem();
				String text = null;

				if (parentItem == null) {
					text = "node " + tree.indexOf(item);
				} else {
					text = parentItem.getText() + " - " + parentItem.indexOf(item);
				}
				
				item.setText(text);
				System.out.println(text);
				item.setItemCount(10);
			}
		});
		
		shell.setLayout(new FillLayout());
		tree.pack();
		
		shell.pack();
		shell.open();
		while(!shell.isDisposed()){
			if(!display.readAndDispatch()){
				display.sleep();
			}
		}
		display.dispose();
	}
}
