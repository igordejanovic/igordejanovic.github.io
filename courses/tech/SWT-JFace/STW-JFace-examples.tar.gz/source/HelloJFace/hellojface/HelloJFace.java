package hellojface;

import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;

public class HelloJFace extends ApplicationWindow{

	public HelloJFace() {
		super(null);
	}

	@Override
	protected Control createContents(Composite parent) {
//		Text text = new Text(parent, SWT.CENTER);
//		text.setText("Hello SWT and JFace!");
//		text.pack();
		Button button = new Button(parent, SWT.ARROW | SWT.DOWN);
		button.pack();
		return parent;
	}

	public static void main(String[] args) {
		HelloJFace awin = new HelloJFace();
		awin.setBlockOnOpen(true);
		awin.open();
		Display.getCurrent().dispose();
	}

}
