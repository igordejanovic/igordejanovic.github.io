package actions;

import org.eclipse.jface.action.ActionContributionItem;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;

public class ActionTest extends ApplicationWindow{

	protected StatusLineManager slm = new StatusLineManager();
	protected StatusAction action = new StatusAction(slm);
	protected ActionContributionItem aci = new ActionContributionItem(action);
	
	public ActionTest() {
		super(null);
		addStatusLine();
		addMenuBar();
		addToolBar(SWT.FLAT|SWT.WRAP);
	}

	@Override
	protected MenuManager createMenuManager() {
		MenuManager mainMenu = new MenuManager();
		MenuManager actionMenu = new MenuManager("Menu");
		mainMenu.add(actionMenu);
		actionMenu.add(this.action);
		return mainMenu;
		
	}

	@Override
	protected StatusLineManager createStatusLineManager() {
		return this.slm;
	}

	@Override
	protected ToolBarManager createToolBarManager(int style) {
		ToolBarManager toolBar = new ToolBarManager();
		toolBar.add(this.action);
		return toolBar;
	}

	@Override
	protected Control createContents(Composite parent) {
		getShell().setText("Action/Contribution Example");
		parent.setSize(290,150);
		aci.fill(parent);
		return parent;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ActionTest actionTest = new ActionTest();
		actionTest.setBlockOnOpen(true);
		actionTest.open();
		Display.getCurrent().dispose();
	}

}
