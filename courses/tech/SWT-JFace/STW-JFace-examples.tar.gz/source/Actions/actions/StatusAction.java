package actions;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.jface.resource.ImageDescriptor;

public class StatusAction extends Action {

	private StatusLineManager sm;
	private int triggerCount = 0;
	
	public StatusAction(StatusLineManager sm) {
		super("&Trigger@Ctrl+T", AS_PUSH_BUTTON);
		setToolTipText("Trigger the Action");
		setImageDescriptor(ImageDescriptor.createFromFile(this.getClass(), "tools.png"));
		this.sm = sm;
	}
	@Override
	public void run() {
		triggerCount++;
		sm.setMessage("The status action has fired. Count: " + this.triggerCount);
	}


}
